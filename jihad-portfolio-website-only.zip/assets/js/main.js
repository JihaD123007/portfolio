/* ==========================================================================
   Riadul Ferdous Jihad — Interactive Portfolio Scripts
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* 1. Welcome Splash Overlay */
  const welcomeEl = document.getElementById('welcomeOverlay');
  if (welcomeEl) {
    const hideWelcome = () => {
      welcomeEl.classList.add('is-hidden');
      try {
        sessionStorage.setItem('rfj_welcomed', '1');
      } catch (_) {
        /* ignore storage restrictions */
      }
    };

    let alreadyWelcomed = false;
    try {
      alreadyWelcomed = sessionStorage.getItem('rfj_welcomed') === '1';
    } catch (_) {
      alreadyWelcomed = false;
    }

    if (alreadyWelcomed || prefersReducedMotion) {
      welcomeEl.classList.add('is-hidden');
    } else {
      window.setTimeout(hideWelcome, 2100);
      welcomeEl.addEventListener('click', hideWelcome);
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !welcomeEl.classList.contains('is-hidden')) {
          hideWelcome();
        }
      });
    }
  }

  /* 2. Mobile Navigation Drawer */
  const menuToggle = document.getElementById('menuToggle');
  const navLinks = document.getElementById('navLinks');

  if (menuToggle && navLinks) {
    const setMenuOpen = (isOpen) => {
      navLinks.classList.toggle('is-open', isOpen);
      menuToggle.setAttribute('aria-expanded', String(isOpen));
    };

    menuToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = !navLinks.classList.contains('is-open');
      setMenuOpen(open);
    });

    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => setMenuOpen(false));
    });

    document.addEventListener('click', (e) => {
      if (navLinks.classList.contains('is-open') && !navLinks.contains(e.target) && e.target !== menuToggle) {
        setMenuOpen(false);
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && navLinks.classList.contains('is-open')) {
        setMenuOpen(false);
        menuToggle.focus();
      }
    });
  }

  /* 3. Scroll Reveal Animations */
  const revealEls = document.querySelectorAll('.rv');
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: '0px 0px -20px 0px' }
    );

    revealEls.forEach((el) => revealObserver.observe(el));
  }

  /* 4. Stat Count-Up Animation */
  const statCounters = document.querySelectorAll('[data-count-target]');
  const formatCount = (value, decimals, suffix, useComma) => {
    let text = decimals > 0 ? value.toFixed(decimals) : Math.round(value).toString();
    if (useComma) {
      text = Number(text).toLocaleString('en-US');
    }
    return text + (suffix || '');
  };

  if (!prefersReducedMotion && 'IntersectionObserver' in window && statCounters.length > 0) {
    const counterObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const el = entry.target;
          const target = parseFloat(el.dataset.countTarget || '0');
          const decimals = parseInt(el.dataset.decimals || '0', 10);
          const suffix = el.dataset.suffix || '';
          const useComma = el.dataset.comma === 'true';
          const duration = 900;
          const start = performance.now();

          const step = (now) => {
            const progress = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = formatCount(target * eased, decimals, suffix, useComma);
            if (progress < 1) {
              requestAnimationFrame(step);
            } else {
              el.textContent = formatCount(target, decimals, suffix, useComma);
            }
          };

          requestAnimationFrame(step);
          observer.unobserve(el);
        });
      },
      { threshold: 0.35 }
    );

    statCounters.forEach((counter) => counterObserver.observe(counter));
  }

  /* 5. Active Nav Scroll-Spy & Back-to-Top Button */
  const backToTopBtn = document.getElementById('backToTop');
  const sections = document.querySelectorAll('section[id]');
  const navItems = document.querySelectorAll('.nav-links a[href^="#"]');

  const handleScroll = () => {
    const scrollY = window.scrollY;
    if (backToTopBtn) {
      backToTopBtn.classList.toggle('is-visible', scrollY > 280);
    }

    let currentId = '';
    sections.forEach((sec) => {
      const top = sec.offsetTop - 130;
      if (scrollY >= top) {
        currentId = sec.getAttribute('id') || '';
      }
    });

    navItems.forEach((item) => {
      const href = item.getAttribute('href');
      item.classList.toggle('is-active', href === '#' + currentId);
    });
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
    });
  }

  /* 6. Toast Feedback, Copy Handle & Share Profile */
  const toastEl = document.getElementById('toast');
  let toastTimer = null;

  const showToast = (message) => {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.classList.add('is-visible');
    if (toastTimer) window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => {
      toastEl.classList.remove('is-visible');
    }, 2400);
  };

  const copyText = async (text) => {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  };

  document.querySelectorAll('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const value = btn.getAttribute('data-copy');
      if (!value) return;
      try {
        await copyText(value);
        showToast('Copied: ' + value);
      } catch (_) {
        showToast('Unable to copy automatically');
      }
    });
  });

  const shareBtn = document.getElementById('shareProfileBtn');
  if (shareBtn) {
    shareBtn.addEventListener('click', async () => {
      const shareData = {
        title: 'Riadul Ferdous Jihad | Digital Creator',
        text: 'Riadul Ferdous Jihad — Digital Creator from Kushtia, Bangladesh.',
        url: window.location.href
      };
      try {
        if (navigator.share) {
          await navigator.share(shareData);
        } else {
          await copyText(window.location.href);
          showToast('Profile link copied to clipboard');
        }
      } catch (err) {
        if (err && err.name !== 'AbortError') {
          try {
            await copyText(window.location.href);
            showToast('Profile link copied to clipboard');
          } catch (_) {
            showToast('Could not share link');
          }
        }
      }
    });
  }
})();
