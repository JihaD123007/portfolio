# Riadul Ferdous Jihad — Personal Portfolio Website

A lightweight, hosting-ready, responsive static personal portfolio website for **Riadul Ferdous Jihad** (Digital Creator, Kushtia, Bangladesh), preserving the original dark-and-gold identity, profile photographs, social statistics, Islamic-inspired quote, and all official social connections.

---

## 1. Project Folder Structure

```text
website/
├── index.html                        # Main semantic HTML5 entry page
├── 404.html                          # Custom 404 Not Found page
├── robots.txt                        # Search engine crawler instructions
├── sitemap.xml                       # XML Sitemap template
├── site.webmanifest                  # Web app manifest
├── _headers                          # Security & caching headers (Netlify / Cloudflare Pages)
├── README.md                         # Setup & deployment guide (English & বাংলা)
└── assets/
    ├── css/
    │   └── style.css                 # Responsive dark & gold stylesheet
    ├── js/
    │   └── main.js                   # Splash, mobile nav, scroll-spy, count-up, share & copy
    ├── icons/
    │   ├── favicon.svg               # Vector monogram favicon
    │   └── favicon-32x32.png         # PNG favicon
    └── images/
        ├── profile-avatar.jpg        # Sidebar avatar photograph
        ├── profile-portrait.jpg      # Hero portrait photograph
        └── apple-touch-icon.png      # iOS/Android web clip icon
```

---

## 2. Quick Deployment Options (Free HTTPS Static Hosting)

### Option A: Netlify (Fastest — Drag & Drop)
1. Create a free account at [netlify.com](https://www.netlify.com/).
2. Open **Sites** → **Add new site** → **Deploy manually**.
3. Drag and drop the entire `website/` folder into the upload area.
4. Your site is live on HTTPS immediately.
5. **Custom Domain:** Go to **Domain management** → **Add a domain** → enter your domain (e.g. `yourdomain.com`) and point your registrar's DNS (`A` record to `75.2.60.5` and `CNAME` `www` to `your-site.netlify.app`, or switch nameservers to Netlify DNS).
6. **HTTPS:** In **Domain management → HTTPS**, click **Verify DNS configuration** → **Provision certificate** (free Let's Encrypt SSL). Enable **Force HTTPS**.

### Option B: Cloudflare Pages
1. Log in to [dash.cloudflare.com](https://dash.cloudflare.com/) → **Workers & Pages** → **Create** → **Pages** → **Upload assets**.
2. Upload the `website/` folder.
3. **Custom Domain & HTTPS:** Under **Custom domains**, add your domain. Cloudflare automatically configures DNS and issues a universal SSL/TLS certificate (HTTPS) with **Always Use HTTPS** enabled.

### Option C: GitHub Pages
1. Create a public/private GitHub repository and upload all contents inside `website/` to the repository root (`index.html` must be at the root of the branch).
2. Go to **Settings** → **Pages** → **Deploy from a branch** → select `main` and `/ (root)`.
3. Under **Custom domain**, enter your domain and check **Enforce HTTPS** after DNS propagation.

### Option D: Traditional cPanel / Shared Hosting
1. Log in to your hosting **cPanel** → open **File Manager** → navigate to `public_html/`.
2. Upload the contents of `website/` (or upload as a `.zip` and click **Extract** inside `public_html/`, ensuring `index.html` sits directly inside `public_html/`).
3. In cPanel → **SSL/TLS Status** (or **Let's Encrypt SSL**), run **AutoSSL** on your domain and `www` subdomain.
4. Enable **Force HTTPS Redirect** under **Domains** in cPanel.

---

## 3. Post-Deployment SEO Checklist
- Replace `https://your-domain.com/` in `sitemap.xml` and `robots.txt` with your real HTTPS domain.
- Optionally add `<link rel="canonical" href="https://your-domain.com/">` and `og:url` in `index.html` once your domain is active.

---

## ৪. নিজের ডোমেইন ও হোস্টিংয়ে ওয়েবসাইট প্রকাশ করার সম্পূর্ণ গাইড (বাংলায়)

নিচের সহজ ধাপগুলো অনুসরণ করে আপনি আপনার ডোমেইন ও হোস্টিংয়ে (অথবা ফ্রি Netlify / Cloudflare Pages-এ) এই ওয়েবসাইটটি লাইভ করতে পারবেন:

### ধাপ ১: ফাইলগুলো প্রস্তুত করা
- `website/` ফোল্ডারের ভেতরের সব ফাইল (`index.html`, `404.html`, `assets/`, `robots.txt`, `sitemap.xml`, `_headers`, `site.webmanifest`) একসাথে রাখুন।
- **গুরুত্বপূর্ণ:** `index.html` এবং `assets` ফোল্ডার যেন একই মেইন ফোল্ডারে থাকে; ফোল্ডারের নাম বা ফাইলের নাম পরিবর্তন করবেন না, নাহলে ছবি বা ডিজাইন লোড হবে না।

### ধাপ ২: হোস্টিংয়ে ওয়েবসাইট আপলোড করা
#### পদ্ধতি ক — cPanel / শেয়ার্ড হোস্টিং (যেমন: Namecheap, Hostinger, ExonHost ইত্যাদি):
1. আপনার হোস্টিং অ্যাকাউন্ট থেকে **cPanel**-এ লগইন করুন।
2. **File Manager**-এ ঢুকুন এবং বাম পাশ থেকে **`public_html`** ফোল্ডারটি খুলুন (আগে কোনো পুরোনো ফাইল থাকলে ব্যাকআপ নিয়ে সরিয়ে দিন)।
3. উপরের **Upload** বাটনে ক্লিক করে `website/` ফোল্ডারের ভেতরের ফাইলগুলোর একটি `.zip` ফাইল আপলোড করুন।
4. আপলোড শেষ হলে `.zip` ফাইলের ওপর ডান-ক্লিক করে **Extract** করুন। খেয়াল রাখুন যেন `index.html` সরাসরি `public_html/index.html` হিসেবে থাকে।

#### পদ্ধতি খ — ফ্রি স্ট্যাটিক হোস্টিং (Netlify — কার্ড ছাড়াই ফ্রি):
1. [netlify.com](https://www.netlify.com/)-এ ফ্রি অ্যাকাউন্ট খুলুন।
2. ড্যাশবোর্ডে **Sites → Add new site → Deploy manually**-তে যান।
3. আপনার কম্পিউটার বা ফোন থেকে পুরো `website` ফোল্ডারটি ড্র্যাগ অ্যান্ড ড্রপ করুন। কয়েক সেকেন্ডের মধ্যেই ওয়েবসাইট লাইভ হয়ে যাবে।

### ধাপ ৩: নিজের কাস্টম ডোমেইন সংযুক্ত করা (Custom Domain)
1. **cPanel হোস্টিং হলে:** আপনার ডোমেইন রেজিস্ট্রারের ড্যাশবোর্ডে (যেখান থেকে ডোমেইন কিনেছেন) গিয়ে হোস্টিং কোম্পানির দেওয়া **Nameserver** দুটি (যেমন: `ns1.yourhost.com`, `ns2.yourhost.com`) সেট করে সেভ করুন।
2. **Netlify হলে:** Netlify-তে **Domain management → Add a domain**-এ আপনার ডোমেইন লিখুন। এরপর আপনার ডোমেইন রেজিস্ট্রারের **DNS Records**-এ গিয়ে:
   - Type: `A`, Name: `@`, Value: `75.2.60.5`
   - Type: `CNAME`, Name: `www`, Value: `your-site.netlify.app`
   যোগ করুন (অথবা Netlify-এর ৪টি Nameserver ব্যবহার করুন)।
3. DNS আপডেট হতে সাধারণত ১০ মিনিট থেকে কয়েক ঘণ্টা সময় লাগতে পারে।

### ধাপ ৪: HTTPS (SSL সার্টিফিকেট) চালু করা
1. **cPanel-এ:** cPanel থেকে **SSL/TLS Status** (অথবা **Let's Encrypt SSL**)-এ গিয়ে আপনার ডোমেইন সিলেক্ট করে **Run AutoSSL** বা **Issue** ক্লিক করুন। এরপর **Domains** অপশন থেকে **Force HTTPS Redirect** অন করে দিন।
2. **Netlify / Cloudflare Pages-এ:** DNS যুক্ত হওয়ার সাথে সাথেই স্বয়ংক্রিয়ভাবে ফ্রি **Let's Encrypt SSL** চালু হয়ে যাবে এবং `https://` দিয়ে নিরাপদভাবে ওয়েবসাইট ওপেন হবে।

### ধাপ ৫: লাইভ করার পর পরীক্ষা
- ব্রাউজারে আপনার ডোমেইন (`https://yourdomain.com`) খুলে দেখুন ছবি, বাংলা-ইংরেজি ফন্ট, Facebook, TikTok, এবং WhatsApp লিংকগুলো ঠিকভাবে কাজ করছে কি না।
- `sitemap.xml` ও `robots.txt` ফাইলে `https://your-domain.com/` এর জায়গায় আপনার আসল ডোমেইন নাম বসিয়ে আপডেট করে দিন।
